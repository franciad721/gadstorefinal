﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gadstore
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.InitData();
            p.start();
        }

        public void start()
        {
            Program p = new Program();

            Console.WriteLine("===============================================================================");
            Console.WriteLine("===============================================================================");
            Console.WriteLine("||                         WELCOME TO GADSTORE!!!                            ||");
            Console.WriteLine("||                            GADGET STORE                                   ||");
            Console.WriteLine("||                                                                           ||");
            Console.WriteLine("===============================================================================");
            Console.WriteLine("===============================================================================\n\n");
            Console.WriteLine("REGISTER or LOG IN? (type 'R' or 'r' if register and 'L' or 'l'if log in )");
            string select = Console.ReadLine();
            if (select == "L" || select == "l")
            {
                p.Login();
            }

            else if (select == "R" || select == "r")
            {
                p.Register();
            }

            else
            {
                Console.WriteLine("Invalid input!!!");
            }

            Console.ReadKey();
        }

        public void Register()
        {
            Success s = new Success();
            Program p = new Program();
            String firstname, lastname, middlename, username, password, birthday;
            Console.WriteLine("===============================================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxx Registration Form xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please input the following **************");
            Console.WriteLine("===============================================================================");
            Console.Write("\tFirst Name:  ");
            firstname = Console.ReadLine();
            Console.Write("\tLast Name:   ");
            lastname = Console.ReadLine();
            Console.Write("\tMiddle Name: ");
            middlename = Console.ReadLine();
            Console.Write("\tBirthday:    ");
            birthday = Console.ReadLine();
            Console.Write("\tUsername:    ");
            username = Console.ReadLine();
            Console.Write("\tPassword:    ");
            password = Console.ReadLine();
            Console.Clear();

            Customer u = new Customer(Guid.NewGuid().ToString(),firstname, lastname, middlename, birthday, username, password);
            DataSet.CustomerList.Add(u);

            s.SUCCESS();
        }

        public void Successful()
        {
            home:
            Program t = new Program();


            string option1, inputbrand, inputunit, inputunit2;
            option1 = Console.ReadLine();


         

                Console.WriteLine("\nSELECT CELLPHONE BRAND\n");
                Console.WriteLine("       A. NOKIA\n       B. SAMSUNG\n       C. LOG OUT\n       D. DISPLAY USER LIST\n       E. EDIT PROFILE");
                Console.Write("CHOOSE:");
                inputbrand = Console.ReadLine();

                if (inputbrand == "A")
                {
                    Console.WriteLine("\n         A. NOKIA 3315\n         B. NOKIA 3310\n         C. NOKIA 6300");
                    Console.Write("CHOOSE:");
                    inputunit = Console.ReadLine();

                    if (inputunit == "A")
                    {
                        string choice;
                        Console.WriteLine("\nNOKIA 3315\n 2000 PESOS\n");
                        Console.WriteLine("Description\n Presyong abot kaya,pwedeg nilabugay\nspecs octacore 5kmah 4g ram");
                        Console.WriteLine("do you want to buy ?");
           
                        choice = Console.ReadLine();


                        if (choice == "Y" || choice == "y")
                        {
                            int quantity, bill, change;
                            int price = 2000;
                            Console.Write("Quantity:");
                            quantity = int.Parse(Console.ReadLine());
                            int total = price * quantity;
                            Console.WriteLine("THE AMOUNT IS " + total, "");
                            Console.Write("INPUT BILL:");
                            bill = int.Parse(Console.ReadLine());
                            change = bill - total;
                            if (change > 0)
                            {
                                Console.WriteLine("the change is " + change, "");
                            }
                            else if (change == 0)
                            {
                                Console.WriteLine("no change");
                            }
                            else
                            {
                                Console.WriteLine("Balance is" + change, "");
                            }

                            goto home;

                        }

                        else
                        {
                            goto home;  
                        }

                    }

                    else if (inputunit == "B")
                    {

                        string choice;
                        Console.WriteLine("\nNOKIA 331O\n 1550 PESOS\n");
                        Console.WriteLine("Description\n Presyong abot kaya,walay kuskus balungos\nspecs octacore 3kmah 1g ram");
                        Console.WriteLine("do you want to buy ?");
                        choice = Console.ReadLine();


                        if (choice == "Y" || choice == "y")
                        {
                            int quantity, bill, change;
                            int price = 1550;
                            Console.Write("Quantity:");
                            quantity = int.Parse(Console.ReadLine());
                            int total = price * quantity;
                            Console.WriteLine("THE AMOUNT IS " + total, "");
                            Console.Write("INPUT BILL:");
                            bill = int.Parse(Console.ReadLine());
                            change = bill - total;
                            if (change > 0)
                            {
                                Console.WriteLine("the change is " + change, "");
                            }
                            else if (change == 0)
                            {
                                Console.WriteLine("no change");
                            }
                            else
                            {
                                Console.WriteLine("Balance is" + change, "");
                            }

                            goto home; 

                        }

                        else
                        {
                            goto home;
                        }


                    }

                    else if (inputunit == "C")
                    {
                        string choice;
                        Console.WriteLine("\nNOKIA 6300\n 5000 PESOS\n");
                        Console.WriteLine("Description\n Presyong abot kaya,pwedeg nilabugay\nspecs octacore 5kmah 4g ram");
                        Console.WriteLine("do you want to buy ?");
                        choice = Console.ReadLine();


                        if (choice == "Y" || choice == "y")
                        {
                            int quantity, bill, change;
                            int price = 5000;
                            Console.Write("Quantity:");
                            quantity = int.Parse(Console.ReadLine());
                            int total = price * quantity;
                            Console.WriteLine("THE AMOUNT IS " + total, "");
                            Console.Write("INPUT BILL:");
                            bill = int.Parse(Console.ReadLine());
                            change = bill - total;
                            if (change > 0)
                            {
                                Console.WriteLine("the change is " + change, "");
                            }
                            else if (change == 0)
                            {
                                Console.WriteLine("no change");
                            }
                            else
                            {
                                Console.WriteLine("Balance is" + change, "");
                            }

                            goto home;

                        }

                        else
                        {
                            goto home;
                        }


                    }


                }


                else if (inputbrand == "B")
                {
                    Console.WriteLine("\n         A. GALAXY X\n         B. GALAXY J1 PRIME\n         C. S7 EDGE");
                    Console.Write("CHOOSE:");
                    inputunit2 = Console.ReadLine();

                    if (inputunit2 == "A")
                    {
                        string choice;
                        Console.WriteLine("\nGALAXY X\n 20000 PESOS\n");
                        Console.WriteLine("Description \nspecs octacore 5kmah 4g ram");
                        Console.WriteLine("do you want to buy ?");
                        choice = Console.ReadLine();


                        if (choice == "Y" || choice == "y")
                        {
                            int quantity, bill, change;
                            int price = 20000;
                            Console.Write("Quantity:");
                            quantity = int.Parse(Console.ReadLine());
                            int total = price * quantity;
                            Console.WriteLine("THE AMOUNT IS " + total, "");
                            Console.Write("INPUT BILL:");
                            bill = int.Parse(Console.ReadLine());

                            change = bill - total;
                            if (change > 0)
                            {
                                Console.WriteLine("the change is " + change, "");
                            }
                            else if (change == 0)
                            {
                                Console.WriteLine("no change");
                            }
                            else
                            {
                                Console.WriteLine("Balance is" + change, "");
                            }

                            goto home;

                        }

                        else
                        {
                            goto home;
                        }


                    }

                    else if (inputunit2 == "B")
                    {

                        string choice;
                        Console.WriteLine("\nGALAXY J1 PRIME\n 25000 PESOS\n");
                        Console.WriteLine("Description \nspecs octacore 6kmah 4g ram");
                        Console.WriteLine("do you want to buy ?");
                        choice = Console.ReadLine();


                        if (choice == "Y" || choice == "y")
                        {
                            int quantity, bill, change;
                            int price = 25000;
                            Console.Write("Quantity:");
                            quantity = int.Parse(Console.ReadLine());
                            int total = price * quantity;
                            Console.WriteLine("THE AMOUNT IS " + total, "");
                            Console.Write("INPUT BILL:");
                            bill = int.Parse(Console.ReadLine());

                            change = bill - total;
                            if (change > 0)
                            {
                                Console.WriteLine("the change is " + change, "");
                            }
                            else if (change == 0)
                            {
                                Console.WriteLine("no change");
                            }
                            else
                            {
                                Console.WriteLine("Balance is" + change, "");
                            }

                            goto home;

                        }

                        else
                        {
                            goto home;
                        }


                    }

                    else if (inputunit2 == "C")
                    {
                        string choice;
                        Console.WriteLine("\nGALAXY J1 PRIME\n 32000 PESOS\n");
                        Console.WriteLine("Description \nspecs octacore 6kmah 4g ram");
                        Console.WriteLine("do you want to buy ?");
                        choice = Console.ReadLine();


                        if (choice == "Y" || choice == "y")
                        {
                            int quantity, bill, change;
                            int price = 32000;
                            Console.Write("Quantity:");
                            quantity = int.Parse(Console.ReadLine());
                            int total = price * quantity;
                            Console.WriteLine("THE AMOUNT IS " + total, "");
                            Console.Write("INPUT BILL:");
                            bill = int.Parse(Console.ReadLine());

                            change = bill - total;
                            if (change > 0)
                            {
                                Console.WriteLine("the change is " + change, "");
                            }
                            else if (change == 0)
                            {
                                Console.WriteLine("no change");
                            }
                            else
                            {
                                Console.WriteLine("Balance is" + change, "");
                            }

                            goto home;
                        }

                        else
                        {
                            goto home;
                        }


                    }


                }
          else if (inputbrand == "C")
                {
                    Console.WriteLine("YOURE ALREADY LOG OUT IN YOUR ACCOUNT.");
                    Program p = new Program();
                    p.homenotlogin();  
                }


                else if (inputbrand == "D")

                {
                    Program p = new Program();
                    p.DISPLAYUSER();
                }


                else if (inputbrand == "E")
                {
                    UPDATEDELETE p = new UPDATEDELETE();
                    p.UPDATE();
                }



                else
                {
                    
                }

                



            }
        public void DISPLAYUSER()
        {
             Program p = new Program();
            {
                Console.WriteLine("==============================================================");
                Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxx Users List xxxxxxxxxxxxxxxxxxxxxxx");
                Console.WriteLine("==============================================================");
                int count = 1;
                foreach (Customer s in DataSet.CustomerList)
                {
                    try
                    {

                        Console.WriteLine(count++ + " " + s.toString());
                    }
                    catch
                    {

                    }
                    p.start();
                }
                Console.WriteLine("Press any key to Continue");
            }
        }
        public void homenotlogin()
        {
            string choices;
            Console.WriteLine("\n\nYOU WANT TO VISIT OUR STORE ?");
            Console.WriteLine("A. LOGIN\nB. REGISTER");
            Console.Write("CHOOSE:");
            choices= Console.ReadLine();
           

            if (choices == "A" || choices == "a")
            {
                Program p = new Program();
                p.Login();
            }

            else if (choices == "B" || choices == "b")
            {
                Program p = new Program();
                p.Register();

            }

        
        }

        public void Login()
        {
        login:
            
            Program p = new Program();
        LOGIINSUCCESS s = new LOGIINSUCCESS();
            string username, password;
            Console.WriteLine("============================================================================");
            Console.WriteLine("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx LOGIN xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
            Console.WriteLine("\t************** Please Input the following **************");
            Console.WriteLine("============================================================================");
            Console.Write("\n\tUsername: ");
            username = Console.ReadLine();
            System.Console.Write("\n\tPassword: ");
            password = null;

            while (true)
            {
                var key = System.Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                    break;
                password += key.KeyChar;
                System.Console.Write("*");

            }
            Console.Clear();

            try
            {
                User respond = DataSet.UserList.Find(r => (r.Username == username) && (r.Password == password));

                switch ((respond.Id))
                {
                    case "l":
                    case "L":
                        Login();
                        break;
                };
            }
            catch
            {

                Console.Clear();
                Console.WriteLine("============================================================================");
                Console.WriteLine("\t\t\t\tThe Account Does'nt exist!");
                Console.WriteLine("============================================================================");
                goto login;
            }
            s.LogINSuccess();
        }
        public void InitData()
        {
            string id1 = Guid.NewGuid().ToString();
            DataSet.UserList.Add(new User(Guid.NewGuid().ToString(), "Dan", "Francia", "C", "April", "uwagan1", "1234"));
            DataSet.UserList.Add(new User(Guid.NewGuid().ToString(), "Renz", "Patual", "L", "April", "uwagan2", "1234"));
        }

   
    }
}

