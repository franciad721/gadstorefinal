﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gadstore
{
    class User
    {
        public String Id, FirstName, LastName, MiddleName, Birthday, Username, Password;
        public User( String id, String firstname, String lastname, String middlename, String birthday, String username, String password)
        {
            this.Id = id;
            this.FirstName = firstname;
            this.LastName = lastname;
            this.MiddleName = middlename;
            this.Birthday = birthday;
            this.Username = username;
            this.Password = password;
        }
        public String toString()
        {
            return
                  "]\n\tID  =\t" + Id + 
                    "\n\tFirstName    =\t'" + FirstName + '\'' +
                    " \n\tLastName     =\t'" + LastName + '\'' +
                    " \n\tMiddleName   =\t'" + MiddleName + '\'' +
                    " \n\tBirthday     =\t'" + Birthday + '\'' +
                    " \n\tUsername     =\t'" + Username + '\'' +
                    " \n\tPassword     =\t'" + Password + '\'' +
                    ']';
        }
        public User(String id, String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            Id = id;
        }
    }
}   
