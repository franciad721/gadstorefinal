﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gadstore
{
    class DataSet
    {
        public static List<Customer> CustomerList = new List<Customer>();
        public static List<User> UserList = new List<User>();
    }
}
