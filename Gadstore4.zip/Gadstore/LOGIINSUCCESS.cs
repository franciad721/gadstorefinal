﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gadstore
{
    class LOGIINSUCCESS: Program
    {
        public String username, password,FirstName, firstname;
        public void LogINSuccess()
        {
            Program p = new Program();
            this.FirstName = firstname;
            User respond = DataSet.UserList.Find(r => (r.Username == username) && (r.Password == password));

            Console.WriteLine("HI WELCOME IN OUR STORE");
            p.Successful();
        }
    }
}
