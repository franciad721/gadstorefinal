﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gadstore
{
    class Success: Program
    {
        //Success s = new Success();
        public void SUCCESS()
        {
            Program p = new Program();
            Console.WriteLine("=====================================");
            Console.WriteLine("=====================================");
            Console.WriteLine("||       Congratulation            ||");
            Console.WriteLine("||     your already register       ||");
            Console.WriteLine("||          GADSTORE!!             ||");
            Console.WriteLine("=====================================");
            Console.WriteLine("=====================================");
            
            p.Successful();
            Console.ReadKey();
            Console.Clear();
        }
    }
}
