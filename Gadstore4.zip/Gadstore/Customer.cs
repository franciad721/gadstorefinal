﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gadstore
{
    class Customer
    {
        public string id;
        public string firstname;
        public string lastname;
        public string middlename;
        public string birthday;
        public string username;
        public string password;
        public Customer(string id, string firstname, string lastname, string middlename, string birthday, string username, string password)
        {
            // TODO: Complete member initialization
            this.firstname = firstname;
            this.lastname = lastname;
            this.middlename = middlename;
            this.birthday = birthday;
            this.username = username;
            this.password = password;
            this.id = id;
        }
         public String toString()
        {
            return
                  "]\n\tFirstName    =\t'" + firstname + '\'' +
                    " \n\tLastName     =\t'" + lastname + '\'' +
                    " \n\tMiddleName   =\t'" + middlename + '\'' +
                    " \n\tUsername     =\t'" + username + '\'' +
                    " \n\tPassword     =\t'" + null + '\'' +
                    ']';

        }
        public Customer(String id, String firstName, String lastName)
        {
            firstname = firstName;
            lastname = lastName;
        }
    }
}
