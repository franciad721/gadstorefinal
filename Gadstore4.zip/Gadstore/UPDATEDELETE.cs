﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gadstore
{
    class UPDATEDELETE
    {
        #region Delete Reservation

        public void DELETE()
        {
            Program p = new Program();
        // UPDATEDELETE d = new UPDATEDELETE();





        login:
            String username, password;

            Console.WriteLine("\n\n\n\n\t\t\t\t\t\t\t                 DELETE YOUR RESERVATION\n\n");
            Console.Write("\n\n\t\t\t\t\t\t\tPlease Input username:");
            username = Console.ReadLine();
            Console.Write("\t\t\t\t\t\t\tPlease Input Password:");
            password = Console.ReadLine();

            try
            {
                User respond = DataSet.UserList.Find(r => (r.Username == username) && (r.Password == password));


                Console.WriteLine("\n\n\t\t\t\t\t\t\tPress D(delete)");
                Console.WriteLine("\t\t\t\t\t\t\tPress C(cancel)");
                Console.Write("\n\t\t\t\t\t\t\tCHOOSE OPTION:");
                string c = Console.ReadLine().ToString();


                switch (c)
                {
                    case "D":
                    case "d":
                        //(respond);

                        Console.WriteLine("\n\n\n\n\n\n\t\t\t\t\t\t\t\t\t\tYour data Has Been Deleted!!!     Thank You..");

                        Console.Write("\n\n\t\t\t\t\t\t\t\t\t\tPress any key to Continue......");

                        Console.ReadLine();
                        Console.Clear();
                        Console.ReadLine();

                        break;
                    case "C":
                    case "c":
                        Console.WriteLine("Thank You Have A Blessed Day!!!");
                        Console.Read();
                        break;

                    default:

                        Console.Write("invalid input");
                        break;
                };

                Console.Read();
            }
            catch
            {
                Console.Clear();
                Console.WriteLine("Invalid Credentials !!!");
                goto login;
            }

        }
        public void Clear(User respond)
        {
            respond.FirstName = null;
            respond.Username= null;
            respond.LastName= null;
            respond.MiddleName = null;
            respond.Password = null;
            respond.Birthday = null;
            respond.Id = null;
            
         

        }


        #endregion

        public void UPDATE()
        {

            Program p = new Program();


            Console.WriteLine("\n\n\n\n\t\t\t\t\t\t\t                 UPDATE YOUR RESERVATION\n\n");


        login:
            String username, password;

            Console.WriteLine("\n\t\t\t\t\t\t\t                      L O G  I N");
            Console.Write("\n\n\t\t\t\t\t\t\tPlease Input User Email:");
            username = Console.ReadLine();
            Console.Write("\t\t\t\t\t\t\tPlease Input Password:");
            password = Console.ReadLine();

            try
            {
                Customer respond = DataSet.CustomerList.Find(r => (r.username == username) && (r.password == password));

                Console.WriteLine("\n\n\t\t\t\t\t\t\tWHAT DO YOU WANT TO CHANGE?");

                Console.WriteLine("\n\n\t\t\t\t\t\t\tA.Employee new Firstname");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tB.Employee new LastName");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tC.Employee new MiddleName");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tD.Employee new Birthday");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tE.Employee new UserName");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tF.Employee new Password");
                Console.WriteLine("\n\n\t\t\t\t\t\t\tG.Employee new ID");

                Console.Write("\n\n\t\t\t\t\t\t\tWhat Is Your Choice?:");
                string Change = Console.ReadLine().ToString();

                if (Change == "A" || Change == "a")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Firstname:");
                    respond.firstname = Console.ReadLine().ToString();
                }
                else if (Change == "B" || Change == "b")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Lastname:");
                    respond.lastname = Console.ReadLine().ToString();
                }
                else if (Change == "C" || Change == "c")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Middlename");
                    respond.middlename = Console.ReadLine().ToString();
                }
                else if (Change == "D" || Change == "d")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Email Account:");
                    respond.birthday = Console.ReadLine().ToString();
                }
                else if (Change == "E" || Change == "e")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Password:");
                    respond.username = Console.ReadLine().ToString();
                }
                else if (Change == "F" || Change == "f")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Address:");
                    respond.password = Console.ReadLine().ToString();
                }
                if (Change == "G" || Change == "g")
                {
                    Console.Write("\n\t\t\t\t\t\t\tInput new Event:");
                    respond.id = Console.ReadLine().ToString();

                }

                {

                    Console.Read();

                }

            }

            catch
            {
                Console.Clear();
                Console.WriteLine("Invalid Credentials !!!");
                goto login;
            }

            p.start();
            Console.Write("\n\t\t\t\t\t\t\tPress any key to Continue......");

            Console.ReadLine();
            p.start();
            Console.Clear();
            Console.ReadLine();


        }

    }
}
